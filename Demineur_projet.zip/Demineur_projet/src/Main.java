public class Main {
	public static void main(String[] args) {
		GamePlay Jeu = new GamePlay();
		
		Jeu.jouer();
	}
}
